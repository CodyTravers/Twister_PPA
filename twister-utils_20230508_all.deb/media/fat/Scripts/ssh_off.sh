#!/bin/bash 
clear
systemctl disable ssh.service
systemctl stop ssh.service
systemctl status ssh.service
