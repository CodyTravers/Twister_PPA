#!/bin/bash
#Edit unit config with your information: /etc/systemd/system/media-fat-cifs.mount
systemctl disable media-fat-cifs.mount
systemctl stop media-fat-cifs.mount
systemctl status media-fat-cifs.mount
