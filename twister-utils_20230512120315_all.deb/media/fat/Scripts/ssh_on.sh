#!/bin/bash 
clear
systemctl enable ssh.service
systemctl start ssh.service
systemctl status ssh.service
