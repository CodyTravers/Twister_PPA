#!/bin/bash
#Edit unit config with your information: /etc/systemd/system/media-fat-cifs.mount
systemctl enable media-fat-cifs.mount
systemctl start media-fat-cifs.mount
systemctl status media-fat-cifs.mount
