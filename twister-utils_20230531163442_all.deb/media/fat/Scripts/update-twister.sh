#!/bin/bash
fbterm
sudo apt update && sudo apt upgrade -y
sleep 5
